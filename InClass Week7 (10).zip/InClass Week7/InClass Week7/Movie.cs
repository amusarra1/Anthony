﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InClass_Week7
{
    class Movie
    {
        private string Title;
        private string Director;
        private int Year;
        private int Rating;
        public Movie(string Title, string Director, int Year)
        {
            this.Title = Title;
            this.Director = Director;
            this.Year = Year;
        }
        public Movie(string Title, int Rating, string Director)
        {
            this.Title = Title;
            this.Director = Director;
            this.Rating = Rating;
        }

        public Movie (string Title)
        {
            this.Title = Title;
        }
        public void Display()
        {
            Console.WriteLine("{0} directed by {1} released in {2}\n", Title, Director, Year);          
        }
    }

}
