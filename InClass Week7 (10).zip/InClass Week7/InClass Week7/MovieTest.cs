﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InClass_Week7
{
    class MovieTest
    {
        static void Main(string[] args)
        {
            Movie myMovie = new Movie("Iron Man", "John Favreau", 2008);

            //myMovie.Title = "Dumbo";

            Movie myFavoriteMovie = new Movie("Rudy", 5, "David Anspaugh");

            Movie myOtherMovie = new Movie("Scar Face");

            myMovie.Display();
            myFavoriteMovie.Display();
            myOtherMovie.Display();

        }
    }
}
